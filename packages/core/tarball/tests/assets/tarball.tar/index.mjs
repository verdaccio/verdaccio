import * as fs from 'fs';
import * as tar from 'tar';
import * as zlib from 'zlib';

async function getTarballDetails(filePath) {
    const gzip = zlib.createGunzip();
    const extractor = tar.list();
    
    let fileSize = 0; 
    let fileCount = 0;
    let uncompressedSize = 0;

    return new Promise((resolve, reject) => {
        fs.createReadStream(filePath)
        .on('data', chunk => {
            fileSize += chunk.length;
        })
        .pipe(gzip)
        .on('error', reject)
        .pipe(extractor)
        .on('error', reject)
        .on('entry', entry => {
            fileCount++;
            uncompressedSize += entry.size;  
        })
        .on('end', () => {
            resolve({
                fileSize,
                fileCount,
                uncompressedSize,
            });
        });
    });
}

getTarballDetails('semver.tgz')
    .then((result) => console.log(result))
    .catch((err) => console.error(err));
